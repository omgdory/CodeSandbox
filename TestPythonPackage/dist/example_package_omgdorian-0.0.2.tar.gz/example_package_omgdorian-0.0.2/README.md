# Test Package

Following "https://packaging.python.org/en/latest/tutorials/packaging-projects/"
Testing how to make a Python package/module to be imported and used.

- omgdorian, 8.22.2023
